Installation

Unzip the package you've downloaded and install the software by running Setup.exe.

To activate your free copy visit the page below. Fill in the form and sumbit your data. The registration key will appear on the same page and will be sent to you by email.
 
After you install, there will be a pop up window. Follow the instructions to create your account, using the license key. 

Please note: If you use one email to get the license on the landing page and different one while creating Sticky Account, then you need to enter the license manually.

-----------------------------------------------------------------

http://www.stickypassword.com/gotd2016

-----------------------------------------------------------------

!!!! .GCD file included is necessary for correct installation and activation. Please make sure to extract all enclosed files to the same folder. After successful activation and installation you may safely delete GOTD installation files from your PC (including .GCD)!!!



You have to install and activate it before the Giveaway offer for the software is over.

Terms and conditions

Please note that the software you download and install 
during the Giveaway period comes with the following important limitations:
1) No free technical support
2) No free upgrades to future versions
3) Strictly non-commercial usage