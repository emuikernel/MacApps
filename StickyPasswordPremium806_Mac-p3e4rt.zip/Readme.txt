Installation

Unzip the package you've downloaded and install the software by running Setup.dmg.

To activate your free copy visit the page below. Fill in the form and sumbit your data. The registration key will appear on the same page and will be sent to you by email.

After you install, there will be a pop up window. Follow the instructions to create your account.

Please note: If you use one email to get the license on the landing page and different one while creating Sticky Account, then you need to enter the license manually.

-----------------------------------------------------------------

http://www.stickypassword.com/gotd2016

-----------------------------------------------------------------


You have to install and activate it before the Giveaway offer for the software is over.

Terms and conditions

Please note that the software you download and install 
during the Giveaway period comes with the following important limitations:
1) No free technical support
2) No free upgrades to future versions
3) Strictly non-commercial usage